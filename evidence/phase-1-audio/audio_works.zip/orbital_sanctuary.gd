extends Node3D

const SfxLibrary = preload("res://sfx/sfx_library.gd")

var played := 0
var names: Array = []
var timer := 0.0

func _ready() -> void:
	var streams := SfxLibrary.load_all()
	names = streams.keys()
	names.sort()
	print("[Audio] loaded ", streams.size(), " imported samples")
	for n in names:
		var s: AudioStream = streams[n]
		print("[Audio] ", n, " -> ", s.get_class(), " ", String.num(s.get_length(), 3), "s")

func _process(delta: float) -> void:
	if played >= names.size():
		return
	timer += delta
	if timer < 0.7:
		return
	timer = 0.0
	var sample_name: String = names[played]
	var player := SfxLibrary.play(self, sample_name)
	print("[Audio] playing ", sample_name, " -> ", "ok" if player != null else "FAILED")
	played += 1
