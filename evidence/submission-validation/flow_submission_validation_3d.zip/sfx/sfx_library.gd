extends Node
## Convenience wrapper over the imported sound suite.
##
## The samples are ordinary imported .wav resources, so load() returns an AudioStreamWAV and
## nothing here has to parse anything. This exists only so a caller can say
## SfxLibrary.play(self, "energy_pickup") instead of wiring a player by hand.

const SUITE_DIR := "res://sfx"

static func load_stream(path: String) -> AudioStream:
	if not ResourceLoader.exists(path):
		push_error("No sample at " + path)
		return null
	return load(path) as AudioStream

## Every sample in the directory, keyed by name: load_all()["laser_fire"].
static func load_all(directory: String = SUITE_DIR) -> Dictionary:
	var streams := {}
	var dir := DirAccess.open(directory)
	if dir == null:
		return streams
	for file_name in dir.get_files():
		# The editor writes a .import sidecar next to each asset; skip it and anything else
		# that is not one of the audio formats Godot imports.
		var extension := file_name.get_extension().to_lower()
		if not extension in ["wav", "ogg", "mp3"]:
			continue
		var stream := load_stream(directory.path_join(file_name))
		if stream != null:
			streams[file_name.get_basename()] = stream
	return streams

## Plays one sample once and frees the player when it finishes.
static func play(parent: Node, name: String, directory: String = SUITE_DIR) -> AudioStreamPlayer:
	var stream := load_stream(directory.path_join(name + ".wav"))
	if stream == null:
		return null
	var player := AudioStreamPlayer.new()
	player.stream = stream
	parent.add_child(player)
	player.finished.connect(player.queue_free)
	player.play()
	return player
