extends Node3D

var sample_elapsed: float = 0.0
var sample_index: int = 0

func _ready() -> void:
	print("[Validation] 3D project ready; clean collision telemetry enabled.")

func _process(delta: float) -> void:
	sample_elapsed += delta
	if sample_elapsed < 0.5:
		return
	sample_elapsed = 0.0
	sample_index += 1
	var crate := get_node_or_null("ValidationCrate") as RigidBody3D
	var ball := get_node_or_null("ValidationBall") as RigidBody3D
	var trigger := get_node_or_null("ValidationTrigger") as Area3D
	var player := get_node_or_null("BotanistPlayer") as CharacterBody3D
	if crate == null or ball == null or trigger == null or player == null:
		return
	var detail := {
		"kind": "collision_validation",
		"sample": sample_index,
		"crate_y": snappedf(crate.global_position.y, 0.001),
		"crate_sleeping": crate.sleeping,
		"ball_y": snappedf(ball.global_position.y, 0.001),
		"ball_sleeping": ball.sleeping,
		"trigger_overlaps": trigger.get_overlapping_bodies().size(),
		"player_x": snappedf(player.global_position.x, 0.001),
		"player_z": snappedf(player.global_position.z, 0.001)
	}
	print("[CollisionProof] ", JSON.stringify(detail))
	if OS.has_feature("web"):
		var json: String = JSON.stringify(detail)
		JavaScriptBridge.eval("window.__godotWebMcpPublishTelemetry(" + json + ");")
